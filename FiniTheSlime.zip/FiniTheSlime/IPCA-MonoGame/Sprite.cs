using System;
using Genbox.VelcroPhysics.Dynamics;
using Genbox.VelcroPhysics.Factories;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace IPCA.MonoGame
{
    // Game Object child
    // represents a game object that has a texture
    public class Sprite : GameObject
    {
        protected enum Direction
        {
            Left,
            Right,
        }
        protected Direction _direction = Direction.Right;

        // TODO: we should not duplicate textures on each instance
        protected Texture2D _texture;
        //protected float scale2=0;
        protected Vector2 _scale;

        public Sprite(string name, Texture2D texture, Vector2 position, float rotation = 0, float xS = 1, float yS = 1) : base(name, position)
        {
            //  scale2 = scale;
            _scale = new Vector2(xS, yS);
            _rotation = rotation;
            _texture = texture;
            _size = _texture.Bounds.Size.ToVector2() / (240 * _scale);  // TODO: HARDCODED!
            _position = position + new Vector2(_size.X, _size.Y) / 2f; // Anchor in the middle
        }


        public override void Update(GameTime gameTime)
        {
            if(Body!=null)
            base.Update(gameTime);
        }

        public override void Draw(SpriteBatch spriteBatch, GameTime gameTime)
        {
            Vector2 pos = Camera.Position2Pixels(_position);
            // Vector2 anchor = _texture.Bounds.Size.ToVector2() / 2f;
            Vector2 anchor = new Vector2(_texture.Width, _texture.Height) / 2;

            Vector2 scale = Camera.Length2Pixels(_size) / 240; // TODO: HARDCODED!
                                                               //scale.Y = scale.X;  // FIXME! TODO: HACK HACK HACK

            spriteBatch.Draw(_texture, pos, null, Color.White,
                _rotation, anchor, scale,
                _direction == Direction.Right ? SpriteEffects.None : SpriteEffects.FlipHorizontally,
                0);

            base.Draw(spriteBatch, gameTime);
        }
    }
}
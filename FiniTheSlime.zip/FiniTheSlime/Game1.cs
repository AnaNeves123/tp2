﻿using Genbox.VelcroPhysics.Dynamics;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using IPCA.MonoGame;
using System;
using System.Collections.Generic;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Media;

namespace FiniTheSlime
{
    public class Game1 : Game
    {
        private GraphicsDeviceManager _graphics;
        private SpriteBatch _spriteBatch;
        private Scene _scene=null;
        private Player _player=null;
        private PlayerUI _playerUI;

        public World _world;

        private List<string> levels = new List<string> { "level1.txt","level2.txt" };
        private int level = 0;

        private Texture2D bkg,_startMenu,_winMenu,_deadMenu;
        private List<Component> _startGameComponents;
        private List<Component> _loseGameComponents;
        private List<Component> _endGameComponents;


        public bool start = false;
        private int menu = 0;
        
        private Song _menuSong, _gameSong;


        public Game1()
        {
            _graphics = new GraphicsDeviceManager(this);
            Content.RootDirectory = "Content";
            IsMouseVisible = true;
            _world = new World(new Vector2(0, -9.82f));
            Services.AddService(_world);
            new KeyboardManager(this);
        }

        protected override void Initialize()
        {
            _graphics.PreferredBackBufferHeight = 768;
            _graphics.PreferredBackBufferWidth = 1280;
            _graphics.ApplyChanges();
            Debug.SetGraphicsDevice(GraphicsDevice);

            new Camera(GraphicsDevice, height: 7.5f);
            Camera.LookAt(Camera.WorldSize / 2f);
            _playerUI = new PlayerUI(this);



            KeyboardManager.Register(
                Keys.R,
                KeysState.GoingDown,
                () =>
                {
                    reloadGame(level);
                });
                base.Initialize();
        }

        protected override void LoadContent()
        { 
            _spriteBatch = new SpriteBatch(GraphicsDevice);

            //https://www.pinterest.pt/pin/119556565098255759/
            bkg = Content.Load<Texture2D>("Cavern");
            _winMenu = Content.Load<Texture2D>("Menu/endMenu");
            _startMenu = Content.Load<Texture2D>("Menu/startMenu");
            _deadMenu = Content.Load<Texture2D>("Menu/deadMenu");
            _menuSong = Content.Load<Song>("MenuMusic2");
            _gameSong = Content.Load<Song>("MenuMusic");

            

            MediaPlayer.Play(_menuSong);
            MediaPlayer.IsRepeating = true;
            MediaPlayer.Volume = 0.1f;
            

            loadMenu();
        }

        protected override void Update(GameTime gameTime)
        {
            if (GamePad.GetState(PlayerIndex.One).Buttons.Back == ButtonState.Pressed || Keyboard.GetState().IsKeyDown(Keys.Escape))
                Exit();

            if (!start)
            {
                switch (menu)
                {
                    case 0:
                        foreach (var component in _startGameComponents)
                            component.Update(gameTime);
                        break;
                    case 1:
                        foreach (var component in _loseGameComponents)
                           component.Update(gameTime);
                        break;
                    case 2:
                        foreach (var component in _endGameComponents)
                            component.Update(gameTime);
                        break;
                }

            }
            else
            {
                _world.Step((float)gameTime.ElapsedGameTime.TotalMilliseconds * 0.001f);

                Rocky.SUpdate();

                _scene.Update(gameTime);

                foreach (SlimeSlice ss in _scene._PickedSlices)
                    if (ss.Body != null)
                    {
                        _world.RemoveBody(ss.Body); ss.Body = null;
                        _player.NgrowShrink(1, true);
                    }

                foreach (Rocky r in _scene._DeadRockys)
                    if (r.Body != null)
                    {
                        _world.RemoveBody(r.Body);
                        r.Body = null;
                    }

                if (!_player.Dead)
                {
                    _player.Update(gameTime);
                    foreach (Projectile pr in _player._deadProjectiles)
                        if (pr.Body != null)
                        {
                            _world.RemoveBody(pr.Body);
                            pr.Body = null;

                        }
                }
                else
                {
                    start = false;
                    menu = 1;
                    MediaPlayer.Play(_menuSong);
                }
            }

            base.Update(gameTime);
        }

        protected override void Draw(GameTime gameTime)
        {
            GraphicsDevice.Clear(Color.CornflowerBlue);
            _spriteBatch.Begin();
            if (!start)
            {
                switch (menu)
                {
                    case 0:
                        _spriteBatch.Draw(_startMenu, GraphicsDevice.Viewport.Bounds, Color.White);
                        foreach (var component in _startGameComponents)
                            component.Draw(gameTime, _spriteBatch);
                       
                        break;
                    case 1:
                        _spriteBatch.Draw(_deadMenu, GraphicsDevice.Viewport.Bounds, Color.White);
                        foreach (var component in _loseGameComponents)
                            component.Draw(gameTime, _spriteBatch);
                   
                        break;
                    case 2:
                        _spriteBatch.Draw(_winMenu, GraphicsDevice.Viewport.Bounds, Color.White);
                        foreach (var component in _endGameComponents)
                            component.Draw(gameTime, _spriteBatch);
                        break;
                }
                
            }
            else
            {
                _spriteBatch.Draw(bkg, GraphicsDevice.Viewport.Bounds, Color.White);
                _scene.DrawBack(_spriteBatch, gameTime);
                if (!_player.Dead)
                    _player.Draw(_spriteBatch, gameTime);
                _scene.Draw(_spriteBatch, gameTime);
                _playerUI.Draw(_spriteBatch, gameTime, _player.SizeSlime + 1, _player.Projectiles) ;
            }
            

            _spriteBatch.End();


            base.Draw(gameTime);
        }


        private void loadMenu()
        {
            #region Menu

            //https://www.youtube.com/watch?v=lcrgj26G5Hg

            Vector2 windowSize = new Vector2(_graphics.PreferredBackBufferWidth,
                        _graphics.PreferredBackBufferHeight);
            Vector2 windowCenter = windowSize / 2f;


            var Start = new Button(Content.Load<Texture2D>("Controls/Button"), Content.Load<SpriteFont>("Font/font"))
            {
                Position = new Vector2(windowCenter.X - 64, windowCenter.Y - 40),
                Text = "Play",
            };

            Start.Click += Play;

            var PlayButton = new Button(Content.Load<Texture2D>("Controls/Button"), Content.Load<SpriteFont>("Font/font"))
            {
                Position = new Vector2(windowCenter.X - 64, windowCenter.Y - 40),
                Text = "PlayAgain",
            };

            PlayButton.Click += PlayAgain;




            var quitButton = new Button(Content.Load<Texture2D>("Controls/Button"), Content.Load<SpriteFont>("Font/font"))
            {

                Position = new Vector2(windowCenter.X - 64, windowCenter.Y + 8),
                Text = "Quit",
            };

            quitButton.Click += QuitButton_Click;




            _startGameComponents = new List<Component>() { Start, quitButton, };
            _loseGameComponents = new List<Component>() { PlayButton, quitButton, };
            _endGameComponents = new List<Component>() { Start, quitButton, };
            #endregion
        }

        private void QuitButton_Click(object sender, System.EventArgs e)
        {
            Exit();
        }


        private void Play(object sender, System.EventArgs e)
        {
            level = 0;
            reloadGame(level);
            start = true;

            MediaPlayer.Play(_gameSong);
        }

        private void PlayAgain(object sender, System.EventArgs e)
        {

            reloadGame(level);
            start = true;

            MediaPlayer.Play(_gameSong);
        }



        private void reloadGame(int i)
        {
            start = true;
            if (_player != null) _player.removeBody(_world);
            foreach (Body b in _world.BodyList) _world.RemoveBody(b); 
            Player.Splayer = null;
            _player = new Player(this);
            _scene = new Scene(this, levels[i]);
            
        }

        public void EndLevel()
        {
            
            level++;
            if (level<levels.Count)
            {
                reloadGame(level);
            }
            else
            {
                MediaPlayer.Play(_menuSong);
                menu = 2;
                start = false;
            }    
        }
    }
}

﻿using Genbox.VelcroPhysics.Dynamics;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using IPCA.MonoGame;
using System;
using System.Collections.Generic;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Media;

namespace FiniTheSlime
{
    public class Game1 : Game
    {
        private GraphicsDeviceManager _graphics;
        private SpriteBatch _spriteBatch;
        private Scene _scene;
        private Player _player;
        private PlayerUI _playerUI;

        public World _world;

        private Texture2D bkg,startMenu,WinMenu;
        private List<Component> _startGameComponents;
        private List<Component> _loseGameComponents;

        
        public bool start = false;

        
        private Song _menuSong, _gameSong;


        public Game1()
        {
            _graphics = new GraphicsDeviceManager(this);
            Content.RootDirectory = "Content";
            IsMouseVisible = true;
            _world = new World(new Vector2(0, -9.82f));
            Services.AddService(_world);
            new KeyboardManager(this);
        }

        protected override void Initialize()
        {
            _graphics.PreferredBackBufferHeight = 768;
            _graphics.PreferredBackBufferWidth = 1280;
            _graphics.ApplyChanges();
            Debug.SetGraphicsDevice(GraphicsDevice);

            new Camera(GraphicsDevice, height: 7.5f);
            Camera.LookAt(Camera.WorldSize / 2f);
            _playerUI = new PlayerUI(this);




            KeyboardManager.Register(
                Keys.R,
                KeysState.GoingDown,
                () =>
                {
                    reloadGame();
                });
                base.Initialize();
        }

        protected override void LoadContent()
        { 
            _spriteBatch = new SpriteBatch(GraphicsDevice);
            bkg = Content.Load<Texture2D>("Cavern");
            WinMenu = Content.Load<Texture2D>("Cavern");
            startMenu = Content.Load<Texture2D>("Cavern");
            _menuSong = Content.Load<Song>("MenuMusic2");
            _gameSong = Content.Load<Song>("MenuMusic");

            

            MediaPlayer.Play(_menuSong);
            MediaPlayer.IsRepeating = true;
            MediaPlayer.Volume = 0.1f;
            

            loadMenu();
        }

        protected override void Update(GameTime gameTime)
        {
            if (GamePad.GetState(PlayerIndex.One).Buttons.Back == ButtonState.Pressed || Keyboard.GetState().IsKeyDown(Keys.Escape))
                Exit();

            if (!start)
            {
                foreach (var component in _startGameComponents)
                    component.Update(gameTime);
            }
            else
            {
                _world.Step((float)gameTime.ElapsedGameTime.TotalMilliseconds * 0.001f);

                Rocky.SUpdate();

                _scene.Update(gameTime);

                foreach (SlimeSlice ss in _scene._PickedSlices)
                    if (ss.Body != null)
                    {
                        _world.RemoveBody(ss.Body); ss.Body = null;
                        _player.NgrowShrink(1,true);
                    }

                foreach (Rocky r in _scene._DeadRockys)
                    if (r.Body != null)
                    {
                        _world.RemoveBody(r.Body);
                        r.Body = null;
                    }

                if (!_player.Dead)
                {
                    _player.Update(gameTime);
                    foreach (Projectile pr in _player._deadProjectiles)
                        if (pr.Body != null)
                        {
                            _world.RemoveBody(pr.Body);
                            pr.Body = null;

                        }
                }
                else reloadGame();
            }

            base.Update(gameTime);
        }

        protected override void Draw(GameTime gameTime)
        {
            GraphicsDevice.Clear(Color.CornflowerBlue);
            _spriteBatch.Begin();
            if (!start)
            {
                _spriteBatch.Draw(startMenu, GraphicsDevice.Viewport.Bounds, Color.White);
                foreach (var component in _startGameComponents)
                    component.Draw(gameTime, _spriteBatch);
            }
            else
            {
                _spriteBatch.Draw(bkg, GraphicsDevice.Viewport.Bounds, Color.White);
                _scene.DrawBack(_spriteBatch, gameTime);
                if (!_player.Dead)
                    _player.Draw(_spriteBatch, gameTime);
                _scene.Draw(_spriteBatch, gameTime);
                _playerUI.Draw(_spriteBatch, gameTime, _player.SizeSlime + 1, _player.Projectiles) ;
            }
            

            _spriteBatch.End();


            base.Draw(gameTime);
        }


        private void loadMenu()
        {
            #region Menu

            //https://www.youtube.com/watch?v=lcrgj26G5Hg

            Vector2 windowSize = new Vector2(_graphics.PreferredBackBufferWidth,
                        _graphics.PreferredBackBufferHeight);
            Vector2 windowCenter = windowSize / 2f;


            var PlayButton = new Button(Content.Load<Texture2D>("Controls/Button"), Content.Load<SpriteFont>("Font/font"))
            {
                Position = new Vector2(windowCenter.X - 64, windowCenter.Y - 40),
                Text = "Play",
            };

            PlayButton.Click += Play;

            var PlayAgainButton = new Button(Content.Load<Texture2D>("Controls/Button"), Content.Load<SpriteFont>("Font/font"))
            {
                Position = new Vector2(windowCenter.X - 64, windowCenter.Y - 40),
                Text = "Play Again",
            };

            PlayButton.Click += PlayAgain;


            var quitButton = new Button(Content.Load<Texture2D>("Controls/Button"), Content.Load<SpriteFont>("Font/font"))
            {

                Position = new Vector2(windowCenter.X - 64, windowCenter.Y + 8),
                Text = "Quit",
            };

            quitButton.Click += QuitButton_Click;




            _startGameComponents = new List<Component>() { PlayButton, quitButton, };
            _loseGameComponents = new List<Component>() { PlayAgainButton, quitButton, };

            #endregion
        }

        private void QuitButton_Click(object sender, System.EventArgs e)
        {
            Exit();
        }


        private void Play(object sender, System.EventArgs e)
        {
            start = true;
            reloadGame();
            MediaPlayer.Play(_gameSong);
        }

        private void PlayAgain(object sender, System.EventArgs e)
        {
        
        }

        private void reloadGame()
        {
            if (_player != null) _player.removeBody(_world);
            foreach (Body b in _world.BodyList) _world.RemoveBody(b); 
            Player.Splayer = null;
            _player = new Player(this);
            _scene = new Scene(this, "level1.txt");
            
        }

        public void EndLevel()
        {
            start = false;
            MediaPlayer.Play(_menuSong);
        }

    }
}

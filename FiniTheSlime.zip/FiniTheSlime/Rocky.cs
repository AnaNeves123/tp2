﻿using System;
using System.Collections.Generic;
using System.Linq;
using Genbox.VelcroPhysics.Dynamics;
using Genbox.VelcroPhysics.Factories;
using IPCA.MonoGame;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;



namespace FiniTheSlime
{
    public class Rocky : AnimatedSprite, ITempObject
    {
        enum Status
        {
            Idle, Crouch, Follow, none
        }


        private int _rockSize;
        private Status _status = Status.Idle;

        private bool crouch = false, move = false, right = false, follow=false;
        private float vel = 2;
        private bool Collided = false;
        public bool IsDead() => Collided;
        private Game1 _game;

        private float startPos, endPos;

        private List<Texture2D> _idleFrames;
        private List<Texture2D> _walkFrames;
        private List<Texture2D> _crouchFrames;

        private static Vector2 _playerP;

        public static void SUpdate()
        {
            if(Player.Splayer!=null)
            _playerP = Player.Splayer.Position;
        }

        public Rocky(Game1 game, Vector2 position, int rs ,float x = 1, float y = 1) :
            base("Enemy", // name
            position, // position
            Enumerable.Range(0, 1).Select(n => game.Content.Load<Texture2D>($"Rock/rockIdle")).ToArray(), x, y) // textures
        {
            _rockSize = rs;
            startPos = position.X - 2;
            endPos = position.X + 2;
            _game = game;

            _idleFrames = _textures;
            _crouchFrames = Enumerable.Range(0, 4).Select(n => game.Content.Load<Texture2D>($"Rock/rockCrouch{n}")).ToList();
            _walkFrames = Enumerable.Range(0, 8).Select(n => game.Content.Load<Texture2D>($"Rock/rockWalk{n}")).ToList();

            _coliderSize = new Vector2(_size.X * 0.75f, _size.Y * 0.8f);
           
            _positionColliderOffSet = new Vector2(0, -0.1f / y);
            Body = BodyFactory.CreateCircle(
               _game.Services.GetService<World>(), _size.Y / 2.5f, 1f,
               _position- _positionColliderOffSet,
               BodyType.Dynamic, this); ;
            Body.Rotation = 0;
            Body.FixedRotation = true;
           
            Body.OnCollision = (a, b, contact) =>
            {
                if (b.GameObject().Name == "Fini")
                {
                    Player.Splayer.rockHit(_rockSize);
                    Collided = true;
                }
            };


            KeyboardManager.Register(
                Keys.P,
                KeysState.GoingDown,
                () =>
                {
                    _status = Status.Crouch;
                });
            KeyboardManager.Register(
                Keys.O,
                KeysState.Down,
                () => { _status = Status.Idle; });

        }

        public override void Update(GameTime gameTime)
        {

            if (_status == Status.Idle)
            {
                Body.LinearVelocity = Vector2.Zero;
                _timer = 10f;
                _textures = _idleFrames;
                _currentTexture = 0;
                _animDelay = 1f;
                

            }
            if (move && follow)
            {
                _timer = 0f;
                _textures = _walkFrames;
                _currentTexture = 0;
                _animDelay = -0.8f;
                
                follow = false;
                Console.WriteLine("follow");
            }
            else
            {
                if (_status == Status.Crouch && !crouch )
                {
                    _timer = 0f;
                    _textures = _crouchFrames;
                    _currentTexture = 0;
                    _animDelay = -0.7f;
                    crouch = true;
                    Console.WriteLine("crouch");
                }
                if (crouch && _currentTexture == 2 && !move) { move = true; follow = true; }
            }

            if (move)
            {
             
                if (_position.X < startPos)
                {
                    vel = 2;
                    _direction = Direction.Left;
                }

                if (_position.X > endPos )
                {
                    vel = -2;
                    _direction = Direction.Right;  
                }

                Body.LinearVelocity = new Vector2(vel, 0);
            }
            
            if (-6 < Position.X - _playerP.X && Position.X - _playerP.X < 6 &&
                 -3.5f < Position.Y - _playerP.Y && Position.Y - _playerP.Y < 1.5f)
                _status = Status.Crouch;

            else { _status = Status.Idle; move = false; crouch = false; }
            


            base.Update(gameTime);
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using Genbox.VelcroPhysics.Dynamics;
using Genbox.VelcroPhysics.Factories;
using IPCA.MonoGame;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;

namespace FiniTheSlime
{
    public class FinishPlat : Sprite
    {
        GameObject finishCollider;
        Game1 _game;
        private float _finalPosition;


        public FinishPlat(Game1 game, string name, Texture2D tx, Vector2 position, float x, float y)
            : base(name, tx, position, 0, x, y)
        {
            _game = game;
            AddRectangleBody(game.Services.GetService<World>(), 1.8f, 0.2f, false, -2.4f, 0,fixX:true);

            _finalPosition = position.Y-3f;
        }

        public override void Update(GameTime gameTime)
        {
            if (Body != null)
            {            
                Body.ApplyForce(new Vector2(0, 15f));
                base.Update(gameTime);

                if(Position.Y < _finalPosition)
                {
                    _game.EndLevel();
                }
            }

            
        }

        public override void Draw(SpriteBatch spriteBatch, GameTime gameTime)
        {
       
            base.Draw(spriteBatch, gameTime);
        }
    }
}

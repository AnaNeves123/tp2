﻿using System;
using System.Collections.Generic;
using System.Linq;
using Genbox.VelcroPhysics.Dynamics;
using Genbox.VelcroPhysics.Factories;
using IPCA.MonoGame;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;

namespace FiniTheSlime
{
    public class SlimeSlice : Sprite, ITempObject
    {
        private bool Collided;
        public bool IsDead() => Collided;
        private Game1 _game;

        public SlimeSlice(Game1 game, Vector2 position) :
            base("Slice", game.Content.Load<Texture2D>("SlimePoints"), // name
            position)
        {

            _game = game;
            Body = BodyFactory.CreateCircle(
                _game.Services.GetService<World>(), _size.Y / 6f, 0f,
                _position,
                BodyType.Static, this);
            Body.IsSensor = true;


            Body.OnCollision = (a, b, contact) =>
            {
                if (b.GameObject().Name == "Fini")
                {
                    Collided = true;
                }

            };
        }
    }
}

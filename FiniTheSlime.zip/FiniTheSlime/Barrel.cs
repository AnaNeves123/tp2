﻿using System;
using System.Collections.Generic;
using System.Linq;
using Genbox.VelcroPhysics.Dynamics;
using Genbox.VelcroPhysics.Factories;
using IPCA.MonoGame;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;

namespace FiniTheSlime
{
    public class Barrel: AnimatedSprite
    {
        enum Status
        {
            Idle, Wake, Boom
        }

        private Status _status = Status.Idle;

        private Game1 _game;

        private List<Texture2D> _wakeUpFrames;
        private List<Texture2D> _explodeFrames;

        private bool Explode = false, Kill = false, Wake = false;
        private SoundEffect _WatterSplash; private SoundEffectInstance _WatterSplashInstance;


        public Barrel(Game1 game,Vector2 position) :
            base("Barrel", // name
            position, // position
            Enumerable.Range(1, 1).Select(n => game.Content.Load<Texture2D>($"BArrel/Barrel{n}")).ToArray()
            , 2.3f, 1.533f) // textures
        {
            _game = game;
            _wakeUpFrames = Enumerable.Range(1, 3).Select(n => game.Content.Load<Texture2D>($"BArrel/Barrel{n}")).ToList();
            _explodeFrames = Enumerable.Range(4, 17).Select(n => game.Content.Load<Texture2D>($"BArrel/Barrel{n}")).ToList();
 
            


            _coliderSize = new Vector2(_size.X * 0.75f, _size.Y * 0.625f);

            AddRectangleBody(_game.Services.GetService<World>(),_coliderSize.X,_coliderSize.Y
                ,false ,- 0.9f,density:0);
            Body.GravityScale = 0;
            Body.IsSensor = true;


            _WatterSplash = game.Content.Load<SoundEffect>("Sounds/WatterSplash");
            _WatterSplashInstance = _WatterSplash.CreateInstance(); _WatterSplashInstance.Volume = 0.2f;


            Body.OnCollision = (a, b, contact) =>
            {
                if (b.GameObject().Name == "Fini" || b.GameObject().Name == "Projectile")
                {
                    if (!Wake)
                    {
                        Wake = true;
                        _textures = _wakeUpFrames;
                        _timer = 0f;
                        _currentTexture = 0;
                        _animDelay = -0.95f;
                    }
                    if (Kill)
                    {
                        Kill = false;
                        Player.Splayer.NgrowShrink(2, false);
                    }
                    
                }

            };

            Body.OnSeparation = (a, b, contact) =>
            {
                if (b.GameObject().Name == "Fini" || b.GameObject().Name == "Projectile")
                {
                    if (!Explode)
                    {
                        Explode = true;
                        _textures = _explodeFrames;
                        _timer = 0f;
                        _currentTexture = 0;
                        _animDelay = -0.98f;
                        _WatterSplashInstance.Play();
                    }
                }
            };

            

        }

        public override void Update(GameTime gameTime)
        {
            if (Body != null)
            {
                base.Update(gameTime);

                if (Wake && _textures != _explodeFrames)
                {
                    if (_currentTexture == _wakeUpFrames.Count - 1)
                    {
                        _animDelay = 1000;
                    }
                }

                if (Explode && _textures != _wakeUpFrames)
                {
                    if (_currentTexture == 8)
                    {
                        if (_sensor == null)
                        {
                            _sensor = FixtureFactory.AttachRectangle(
                        _coliderSize.X * 3f, _coliderSize.Y * 2.5f, 0,
                        new Vector2(0, 0.5f), Body);
                            _sensor.IsSensor = true;
                            Kill = true;
                        }
                    }


                    if (_currentTexture == _explodeFrames.Count - 1)
                    {

                        Kill = false;
                        _animDelay = 1000;
                    }
                }
            }
        }


        public override void Draw(SpriteBatch spriteBatch, GameTime gameTime)
        {
            base.Draw(spriteBatch, gameTime);
        }

    }
}

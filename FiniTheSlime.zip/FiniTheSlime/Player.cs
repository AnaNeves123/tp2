using System;
using System.Collections.Generic;
using System.Linq;
using Genbox.VelcroPhysics.Dynamics;
using Genbox.VelcroPhysics.Factories;
using IPCA.MonoGame;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;

namespace FiniTheSlime
{
    public class Player : AnimatedSprite 
    {
        enum Status
        {
            Idle, Walk, Jump
        }

        private Status _status = Status.Idle;

        private Game1 _game;
        public static Player Splayer;

        private bool _Dead=false;
        public bool Dead => _Dead;


       
        

        private List<Projectile> _projectile;
        public List<Projectile> _deadProjectiles;

        private Texture2D _rock;
        private List<Texture2D> _idleFrames;
        private List<Texture2D> _walkFrames;
        private List<Texture2D> _jumpFrames;

        
        private List<int> _projectileCapacity = new List<int> { 1, 1, 1, 2, 2, 2, 3, 3, 3 };
        private List<int> _jumpForce = new List<int> { 47, 90, 125, 160, 180, 210, 330, 300, 290 };
        private List<int> _Weight = new List<int> { 2, 4, 6, 8, 10, 12, 21, 23, 25 };
        private List<float> _moveForce = new List<float> { 4.4f, 4.3f, 4.2f, 4.1f, 4f, 3.9f, 4.5f, 4.5f, 4.5f };

        private int _nProjectiles = 0;
        private int nSize;
        public int Projectiles => _nProjectiles;
        public int SizeSlime => nSize;

        private bool _isGrounded = false;

        private SoundEffect _Jump; private SoundEffectInstance _JumpInstance;
        private SoundEffect _Throw; private SoundEffectInstance _ThrowInstance;

        public Player(Game1 game) :
            base("Fini", // name
            new Vector2(5f, 5f), // position
            Enumerable.Range(1, 2).Select(n => game.Content.Load<Texture2D>($"Fini/FiniIdle{n}")).ToArray()) // textures
        {
            if (Splayer != null) throw new Exception("called more than once.");
            Splayer = this;

            _Jump = game.Content.Load<SoundEffect>("Sounds/slimeJump");
            _JumpInstance = _Jump.CreateInstance(); _JumpInstance.Volume = 0.4f;
            _Throw = game.Content.Load<SoundEffect>("Sounds/rockThrow");
            _ThrowInstance = _Throw.CreateInstance(); _ThrowInstance.Volume = 0.4f;

            _game = game;

            _idleFrames = _textures;
            _walkFrames = Enumerable.Range(1, 1).Select(n => game.Content.Load<Texture2D>($"Fini/FiniWalk{n}")).ToList();
            _jumpFrames = Enumerable.Range(1, 2).Select(n => game.Content.Load<Texture2D>($"Fini/FiniJump{n}")).ToList();

            _rock = _game.Content.Load<Texture2D>("Rock/RockDead");
            _projectile = new List<Projectile>();

            _coliderSize = new Vector2(_size.X * 0.85f, _size.Y * 0.6f);

            nSize = 4;
            AddRectangleBody(_game.Services.GetService<World>(), 0.01f, 0.01f,density:0);


            _body = FixtureFactory.AttachRectangle(_coliderSize.X, _coliderSize.Y, 0, new Vector2(0, 0), Body);
            _bodyWeight = FixtureFactory.AttachRectangle(0.2f, 0.2f, _Weight[nSize], new Vector2(0, 0), Body);

            //
            // kinematic is false by default

            _sensor = FixtureFactory.AttachRectangle(
                _coliderSize.X * 0.5f, _coliderSize.Y * 0.15f, 0,
                new Vector2(0, -_coliderSize.Y / 2f), Body);
            _sensor.IsSensor = true;

            _sensor.OnCollision = (a, b, contact) =>
            {
                if (b.GameObject().Name != "Projectile" && b.GameObject().Name != "Enemy")
                    _isGrounded = true;
            };
            _sensor.OnSeparation = (a, b, contact) => _isGrounded = false;

            
            _rotation = 1.4f;


            #region Registos
            KeyboardManager.Register(
                Keys.W,
                KeysState.GoingDown,
                () => { if (Body != null)
                        if (_isGrounded) {
                            Body.ApplyForce(new Vector2(0, _jumpForce[nSize]));
                            _JumpInstance.Play();
                        }
                });
            KeyboardManager.Register(
                Keys.A,
                KeysState.Down,
                () => { if (Body != null) if (Body.LinearVelocity.X > -_moveForce[nSize]) Body.ApplyForce(new Vector2(-_moveForce[nSize], 0)); });
            KeyboardManager.Register(
                Keys.D,
                KeysState.Down,
                () => { if (Body != null) if (Body.LinearVelocity.X < _moveForce[nSize]) Body.ApplyForce(new Vector2(_moveForce[nSize], 0)); });
            KeyboardManager.Register(
                Keys.U,
                KeysState.GoingDown,
                () => { if (Body != null) NgrowShrink(1, false); });
            KeyboardManager.Register(
                Keys.J,
                KeysState.GoingDown,
                () => { if (Body != null) NgrowShrink(1, true); });

            KeyboardManager.Register(
                Keys.F, KeysState.GoingDown,
                () =>
                {
                    if (Body != null && _nProjectiles > 0)
                    {
                        _nProjectiles--;
                        Vector2 pixelClick = Mouse.GetState().Position.ToVector2();
                        Vector2 pixelDyno = Camera.Position2Pixels(_position);
                        Vector2 delta = pixelClick - pixelDyno;
                        delta.Normalize();
                        delta.Y = -delta.Y; // Invert for "virtual" world
                        Vector2 dir = 5f * delta;

                        Projectile bullet = new Projectile(_rock, _position,
                            dir, game.Services.GetService<World>());
                        _projectile.Add(bullet);

                        Body.ApplyForce(-dir*2);

                        _ThrowInstance.Play();
                    }
                }
                );
            #endregion
        }

        public override void Update(GameTime gameTime)
        {
            
            foreach (Projectile pr in _projectile)
              pr.Update(gameTime);
            if (_isGrounded)
            {

                if ((_status == Status.Walk || _status == Status.Jump) && Body.LinearVelocity.LengthSquared() <= 0.001f)
                {

                    _status = Status.Idle;
                    _timer = 10f;
                    _textures = _idleFrames;
                    _currentTexture = 0;
                    _direction = Direction.Right;
                    _animDelay = 0f;
                }


                if ((_status == Status.Idle || _status == Status.Jump) && Body.LinearVelocity.LengthSquared() > 0.001f)
                {
                    _status = Status.Walk;
                    _timer = 10f;
                    _textures = _walkFrames;
                    _currentTexture = 0;
                    _animDelay = 0f;
                }
            }
            else
            {


                if (Body.LinearVelocity.Y > 2f)
                {
                    _status = Status.Jump;
                    _textures = _jumpFrames;
                    _currentTexture = 0;
                    _animDelay = 1000f;
                }
                else
                {
                    if (Body.LinearVelocity.Y < -2f)
                    {
                        _status = Status.Jump;
                        _textures = _jumpFrames;
                        _currentTexture = 1;
                        _animDelay = 1000f;
                    }
                }
            }


            if (Body.LinearVelocity.X < 0.001f && _status != Status.Idle) _direction = Direction.Left;
            else if (Body.LinearVelocity.X > 0.001f && _status != Status.Idle) _direction = Direction.Right;

            
            base.Update(gameTime);
            Camera.LookAt(_position);

            
            _deadProjectiles = _projectile.Where(b => b.IsDead()).ToList();
            _projectile = _projectile.Where(b => !b.IsDead()).ToList();
        }

        public override void Draw(SpriteBatch spriteBatch, GameTime gameTime)
        {
            base.Draw(spriteBatch, gameTime);
            foreach (Projectile pr in _projectile)
            pr.Draw(spriteBatch, gameTime);
        }

        private void growShrink(bool grSh)
        {
            bool ok = false;
            float qt = 0;
            if (grSh)
            {
                if (nSize < 8) { qt = 0.1f; nSize++; ok = true; }

            }
            else
            {
                if (nSize > 0) { nSize--; ok = true; qt = -0.1f; } else _Dead = true;
            }

            if (ok)
            {
                _coliderSize += new Vector2(qt * 0.85f, qt * 0.6f);
                _size.X = _coliderSize.X * (1 / 0.85f);
                _size.Y = _coliderSize.Y * (1 / 0.6f);

                removeFixtures();
                _bodyWeight = FixtureFactory.AttachRectangle(0.2f, 0.2f, _Weight[nSize], new Vector2(0, 0), Body);
                _body = FixtureFactory.AttachRectangle(_coliderSize.X, _coliderSize.Y,
                    0
                    , new Vector2(0, 0), Body);
                // kinematic is false by default

                _sensor = FixtureFactory.AttachRectangle(
                   _coliderSize.X * 0.8f, _coliderSize.Y * 0.15f,
                   0, new Vector2(0, -_coliderSize.Y / 2f),
                   Body);
                _sensor.IsSensor = true;

                _sensor.OnCollision = (a, b, contact) =>
                {
                    string[] ignore = { "Barrel", "Projectile", "Enemy" };
                    if (!ignore.Contains(b.GameObject().Name))
                    {
                        _isGrounded = true;
                    }
                };
                checkProjectiles();
                _sensor.OnSeparation = (a, b, contact) => _isGrounded = false;

            }


        }


        public void rockHit(int rockSize)
        {
            
            switch (nSize)
            {
                case 0: case 1: case 2:
                    NgrowShrink(2, false);
                    break;
                case 3: case 4: case 5:
                    switch (rockSize)
                    {
                        case 0: _nProjectiles++; checkProjectiles(); break;
                        case 1: _nProjectiles++; NgrowShrink(1, false); break;
                        case 2: NgrowShrink(2, false); break;  
                    }
                    break;
                case 6: case 7: case 8:
                    switch (rockSize)
                    {
                        case 0: _nProjectiles++; checkProjectiles(); break;
                        case 1: _nProjectiles += 2; checkProjectiles(); break;
                        case 2: _nProjectiles++; NgrowShrink(3, false); break;
                    }
                    break;
            }
            
        }

        public void NgrowShrink(int num,bool type)
        {
            for(int i = 0; i < num; i++)
            {
                growShrink(type);
            }
        }


        public void removeBody(World w)
        {
            w.RemoveBody(Body);
            Body = null;
        }

        public void checkProjectiles()
        {
            if (_projectileCapacity[nSize] < _nProjectiles)
            {
                _nProjectiles = _projectileCapacity[nSize];
            }
        }

    }
}
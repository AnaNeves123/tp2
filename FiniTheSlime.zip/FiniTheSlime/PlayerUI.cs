﻿using Genbox.VelcroPhysics.Dynamics;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using IPCA.MonoGame;
using System;
using System.Collections.Generic;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Media;


namespace FiniTheSlime
{
    public class PlayerUI
    {
        private Texture2D _healthBar, _rockBar, _healthHeart, _rockHeart;
        Game1 _game;
        private Vector2 anchor; 

        public PlayerUI(Game1 game)
        {
            _game = game;
            _healthBar = _game.Content.Load<Texture2D>("SlimeUI/HealthBar");
            _rockBar = _game.Content.Load<Texture2D>("SlimeUI/RockBar");
            _healthHeart = _game.Content.Load<Texture2D>("SlimeUI/SlimeHeart");
            _rockHeart = _game.Content.Load<Texture2D>("SlimeUI/RockHeart");
        }


        public virtual void Draw(SpriteBatch spriteBatch, GameTime gameTime,int nLives,int nProjectiles)
        {

            anchor = new Vector2(_healthBar.Width, _healthBar.Height) / 2;
            spriteBatch.Draw(_healthBar, new Vector2(190, 25), null, Color.White,
                0, anchor, 0.5f, SpriteEffects.None, 0);

            anchor = new Vector2(_healthHeart.Width, _healthHeart.Height) / 2;
            for (int i = 0; i < nLives; i++) 
                spriteBatch.Draw(_healthHeart, new Vector2(i*40 + 30,25), null, Color.White,
                    0, anchor, 0.5f, SpriteEffects.None, 0);
            
            //30 , 70 , 110 , 150

            anchor = new Vector2(_rockBar.Width, _rockBar.Height) / 2;
            spriteBatch.Draw(_rockBar, new Vector2(70, 65) , null, Color.White,
                0, anchor, 0.5f, SpriteEffects.None, 0);


            anchor = new Vector2(_rockHeart.Width, _rockHeart.Height) / 2;
            for (int i = 0; i < nProjectiles; i++)
                spriteBatch.Draw(_rockHeart, new Vector2(i * 40 + 30, 65), null, Color.White,
                    0, anchor, 0.5f, SpriteEffects.None, 0);


        }
    }
}

﻿using System.Collections.Generic;
using System.IO;
using System.Linq;
using Genbox.VelcroPhysics.Dynamics;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using System;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using IPCA.MonoGame;

namespace FiniTheSlime
{
    public class Scene
    {
        private List<Sprite> _sprites, _bSprites;
        private FinishPlat _finishPlat;
        private List<Barrel> _barrels;

        private List<SlimeSlice> _Slices;
        public List<SlimeSlice> _PickedSlices;
        private List<Rocky> _Rockys;
        public List<Rocky> _DeadRockys;

        List<Texture2D> _WallTextures = new List<Texture2D>();
        List<Texture2D> _WoodPlatTextures = new List<Texture2D>();
        Texture2D _finishTx,_barrelTx;
        private string[] _linhas;
        private int _nrLinhas, _nrColunas;
        private Sprite bk;

        


        public Scene(Game1 game, string mapName)
        {
            _sprites = new List<Sprite>(); _bSprites = new List<Sprite>();

            _barrels = new List<Barrel>();

            _Slices = new List<SlimeSlice>(); _PickedSlices = new List<SlimeSlice>();

            _Rockys = new List<Rocky>(); _DeadRockys = new List<Rocky>();

            _WallTextures.AddRange(Enumerable.Range(0, 7).Select(n => game.Content.Load<Texture2D>($"Ground/Ground{n}")).ToList()); // 0 - 6
            _WallTextures.AddRange(Enumerable.Range(0, 4).Select(n => game.Content.Load<Texture2D>($"Ground/GroundB{n}")).ToList()); // 7 - 10

            _WoodPlatTextures.AddRange(Enumerable.Range(0, 3).Select(n => game.Content.Load<Texture2D>($"WoodPlats/WoodPlat{n}")).ToList()); // 0 - 2

            _finishTx = game.Content.Load<Texture2D>("WoodPlats/WoodPlatFinish");
            _barrelTx = game.Content.Load<Texture2D>("BArrel/Barrel1");


            _linhas = File.ReadAllLines("Content/"+ mapName);
            _nrLinhas = _linhas.Length; _nrColunas = _linhas[0].Length;


            Sprite sprite;
            SlimeSlice slice;
            Rocky rock;

            for (int x = 0; x < _nrColunas; x++)
                for (int y = 0; y < _nrLinhas; y++)
                    switch (_linhas[y][x])
                    {
                        #region stone Walls
                        case 'B':
                            sprite = new Sprite("Ground0", _WallTextures[0],
                      new Vector2(x, y + _nrLinhas - y * 2)); _sprites.Add(sprite); break;

                        case 'G':
                            sprite = _createGroundLayer(y, x, 'G');
                            if (sprite != null)
                            {
                                sprite.AddRectangleBody(game.Services.GetService<World>(), 0.85f, 0.85f, isKinematic: true);
                                _sprites.Add(sprite);
                            }
                            break;

                        case 'g':
                            sprite = _createGroundLayer(y, x, 'g');
                            if (sprite != null) _sprites.Add(sprite); break;


                        #endregion

                        #region WoodPlats
                        case 'W':
                            sprite = new Sprite("Plat", _WoodPlatTextures[2],
                            new Vector2(x, y + _nrLinhas - y * 2)); _bSprites.Add(sprite);
                            sprite.AddRectangleBody(game.Services.GetService<World>(), 1f, 0.333f, isKinematic: true, 0.333f);
                            if (_linhas[y + 1][x] == 'w')
                            {
                                sprite = new Sprite("Pillar", _WoodPlatTextures[1],
                                new Vector2(x, y + _nrLinhas - y * 2)); _sprites.Add(sprite);
                            }
                            if (_linhas[y][x + 1] == 'G')
                            {
                                sprite = new Sprite("Plat", _WoodPlatTextures[2],
                                new Vector2(x + 1, y + _nrLinhas - y * 2)); _bSprites.Add(sprite);
                            }
                            if (_linhas[y][x - 1] == 'G')
                            {
                                sprite = new Sprite("Plat", _WoodPlatTextures[2],
                                new Vector2(x - 1, y + _nrLinhas - y * 2)); _bSprites.Add(sprite);
                            }
                            break;
                        #endregion

                        #region level End
                        case 'F':
                            int pF = -1;
                            if (_linhas[y][x - 1] == 'G') sprite = new Sprite("Ground1", _WallTextures[7],
                                 new Vector2(x, y + _nrLinhas - y * 2));
                            else
                            {
                                sprite = new Sprite("Ground1", _WallTextures[8],
                            new Vector2(x, y + _nrLinhas - y * 2)); pF = 1;
                            }

                            _sprites.Add(sprite);
                            sprite.AddRectangleBody(game.Services.GetService<World>(),
                                0.2f, 0.2f, isKinematic: true, 0.325f, 0.4f * pF); break;

                        case 'f':
                            int pf = -1;
                            if (_linhas[y][x - 1] == 'g') sprite = new Sprite("Ground1", _WallTextures[9],
                                 new Vector2(x, y + _nrLinhas - y * 2));
                            else
                            {
                                sprite = new Sprite("Ground1", _WallTextures[10],
                            new Vector2(x, y + _nrLinhas - y * 2)); pf = 1;
                            }

                            _sprites.Add(sprite);
                            sprite.AddRectangleBody(game.Services.GetService<World>(),
                                0.2f, 2.85f, isKinematic: true, 0f, 0.675f * pf); break;

                        case 'b':
                            sprite = new Sprite("Ground1", _WallTextures[0],
                                 new Vector2(x, y + _nrLinhas - y * 2));
                            _sprites.Add(sprite);
                            sprite.AddRectangleBody(game.Services.GetService<World>(),
                               0.85f, 0.85f, isKinematic: true, -3f); break;

                        case 'E':
                            _finishPlat = new FinishPlat(game, "Finish", _finishTx, new Vector2(x + 0.5f, y - 1.5f + _nrLinhas - (y - 1.5f) * 2), 2f, 5f);
                            break;


                        #endregion

                        
                        case 'O':
                            if (_linhas[y + 1][x] == 'G')
                            _barrels.Add(new Barrel(game, new Vector2(x - 0.155f, y - 0.6f + _nrLinhas - (y - 0.6f) * 2)));
                            else _barrels.Add(new Barrel(game, new Vector2(x - 0.155f, y - 0.65f + _nrLinhas - (y - 0.65f) * 2)));

                            break;

                         case 'o':
                            if (_linhas[y + 1][x] == 'G')
                            sprite = new Sprite("Objects", _barrelTx, new Vector2(x - 0.155f, y - 0.6f + _nrLinhas - (y - 0.6f) * 2), 0, 2.3f, 1.533f);
                            else sprite = new Sprite("Objects", _barrelTx, new Vector2(x - 0.155f, y - 0.65f + _nrLinhas - (y - 0.65f) * 2), 0, 2.3f, 1.533f);
                            _bSprites.Add(sprite);
                            
                            break;

                        case 's': slice = new SlimeSlice(game,new Vector2(x, y + _nrLinhas - y * 2));
                            _Slices.Add(slice);
                            break;

                        case '3':
                            rock = new Rocky(game, new Vector2(x, y + _nrLinhas - y * 2),2,0.7f,0.7f);
                            _Rockys.Add(rock);
                            break;

                        case '2':
                            rock = new Rocky(game, new Vector2(x, y + _nrLinhas - y * 2),1 ,1.1f, 1.1f);
                            _Rockys.Add(rock);
                            break;

                        case '1':
                            rock = new Rocky(game, new Vector2(x, y + _nrLinhas - y * 2),0,1.6f,1.6f);
                            _Rockys.Add(rock);
                            break;

                    }

            for (int x = 0; x < _nrColunas; x++)
                for (int y = 0; y < _nrLinhas; y++)
                    switch (_linhas[y][x])
                    {
                        case 'w':
                            sprite = new Sprite("Pillar", _WoodPlatTextures[1],
                            new Vector2(x, y + _nrLinhas - y * 2)); _sprites.Add(sprite);
                            if (_linhas[y + 1][x] == 'G')
                            {
                                sprite = new Sprite("Plat", _WoodPlatTextures[0],
                                new Vector2(x, (y + 1) + _nrLinhas - (y + 1) * 2)); _sprites.Add(sprite);
                            }
                            break;
                    }

        }

        private Sprite _createGroundLayer(int y, int x, char ch)
        {
            char xm = _linhas[y][x - 1], xM = _linhas[y][x + 1],
                 ym = _linhas[y - 1][x], yM = _linhas[y + 1][x];
            float rotation = 0f; Texture2D tx = null; char oCh;

            if (ch == 'G') oCh = 'g'; else oCh = 'G';
            if (xm == 'F') xm = 'G';
            if (xM == 'F') xM = 'G';
            if (xm == 'f') xm = 'g';
            if (xM == 'f') xM = 'g';

            if (xm == ch && xM == ch)
            {
                if (ym == oCh) rotation = 1f; else rotation = 0f;
                if (ch == 'G') tx = _WallTextures[1]; else { tx = _WallTextures[4]; rotation += 1; }
            }
            else
            if (ym == ch && yM == ch)
            {
                if (xm == oCh) rotation = 0.5f; else rotation = 1.5f;
                if (ch == 'G') tx = _WallTextures[1]; else { tx = _WallTextures[4]; rotation += 1; }
            }
            else
            {
                if (yM == ch && xM == ch) if (!(ym != oCh || xm != oCh))
                        if (ch == 'G') { rotation = 0.5f; tx = _WallTextures[2]; }
                        else { rotation = 1.5f; tx = _WallTextures[6]; }
                    else if (ch == 'G') { rotation = 1.5f; tx = _WallTextures[3]; }
                    else { rotation += 0.5f; tx = _WallTextures[5]; }

                if (ym == ch && xM == ch) if (!(yM != oCh || xm != oCh))
                        if (ch == 'G') { rotation = 0f; tx = _WallTextures[2]; }
                        else { rotation = 1f; tx = _WallTextures[6]; }
                    else if (ch == 'G') { rotation = 1f; tx = _WallTextures[3]; }
                    else { rotation += 0f; tx = _WallTextures[5]; }

                if (yM == ch && xm == ch) if (!(ym != oCh || xM != oCh))
                        if (ch == 'G') { rotation = 1f; tx = _WallTextures[2]; }
                        else { rotation = 0f; tx = _WallTextures[6]; }
                    else if (ch == 'G') { rotation = 0f; tx = _WallTextures[3]; }
                    else { rotation += 1f; tx = _WallTextures[5]; }

                if (ym == ch && xm == ch) if (!(yM != oCh || xM != oCh))
                        if (ch == 'G') { rotation = 1.5f; tx = _WallTextures[2]; }
                        else { rotation = 0.5f; tx = _WallTextures[6]; }
                    else if (ch == 'G') { rotation = 0.5f; tx = _WallTextures[3]; }
                    else { rotation += 1.5f; tx = _WallTextures[5]; }
            }

            if (tx == null) return null;

            return new Sprite("Ground1", tx,
                            new Vector2(x, y + _nrLinhas - y * 2), (float)Math.PI * rotation);

        }

        public virtual void Update(GameTime gameTime)
        {
            if(_finishPlat!=null) _finishPlat.Update(gameTime);
            foreach (Barrel b in _barrels) b.Update(gameTime);
            foreach (SlimeSlice s in _Slices) s.Update(gameTime);
            foreach (Rocky r in _Rockys) r.Update(gameTime);

            _PickedSlices = _Slices.Where(b => b.IsDead()).ToList();
            _Slices = _Slices.Where(b => !b.IsDead()).ToList();
            _DeadRockys = _Rockys.Where(b => b.IsDead()).ToList();
            _Rockys = _Rockys.Where(b => !b.IsDead()).ToList();

        }


        public void Draw(SpriteBatch spriteBatch, GameTime gameTime)
        {

            

            foreach (Sprite sprite in _sprites) sprite.Draw(spriteBatch, gameTime);
            
            
        }

        public void DrawBack(SpriteBatch spriteBatch, GameTime gameTime)
        {

            

            if (_bSprites != null)
            foreach (Sprite sprite in _bSprites) sprite.Draw(spriteBatch, gameTime);

            foreach (Barrel b in _barrels) b.Draw(spriteBatch, gameTime);

            if(_finishPlat!=null) _finishPlat.Draw(spriteBatch, gameTime);
            foreach (SlimeSlice s in _Slices) s.Draw(spriteBatch, gameTime);
            foreach (Rocky r in _Rockys) r.Draw(spriteBatch, gameTime);


        }

        public void destroyScene(World w)
        {
            foreach (Sprite sprite in _bSprites) { sprite.removeBodyWorld(w); }
            foreach (Sprite sprite in _sprites) sprite.removeBodyWorld(w);
            foreach (Barrel b in _barrels) b.removeBodyWorld(w);
            _finishPlat.removeBodyWorld(w);
        }
    }
}